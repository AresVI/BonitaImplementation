(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customWidgetAttributeRecommendation', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope) {
    
},
      template: '<h3>Auditoría de la Actividad - {{properties.auditTaskRecommendation.auditTask.name}} <br/>\n<small>Proceso: {{properties.auditTaskRecommendation.auditTask.container.auditProcess.name}}</small>\n</h3>\n<hr/>\n<div class="panel panel-default">\n    <div class="panel-body">\n        <h4>Datos:</h4>\n        <div class="panel panel-default" ng-repeat="attrCatRecom in properties.auditTaskRecommendation.categoryAttrRecommendationSet">\n          <div class="panel-heading">\n            <h5 class="panel-title">{{attrCatRecom.categoryAttribute.name}}</h5>\n          </div>\n          <div class="panel-body">\n            <div class="checkbox" ng-repeat="attrRecomm in attrCatRecom.attributeRecommendationSet">\n            <label>\n              <input type="checkbox" ng-model="attrRecomm.implemented"> {{attrRecomm.attribute.name}}\n            </label>\n          </div>\n          </div>\n        </div>\n    </div>\n</div>\n\n<div class="panel panel-default">\n    <div class="panel-body">\n        <h4>Observaciones:</h4>\n         <select class="form-control" style="margin-bottom: 30px;" name="standard_observation" id="field_standard_observation"\n                    ng-model="properties.auditTaskRecommendation.standardObservation">\n            <option value=""> -- Sin observación predefinida -- </option>\n            <option ng-repeat="atso in properties.auditTaskStandardObservations" value="{{atso.observation}}">{{atso.observation}}</option>\n        </select>\n        <textarea class="form-control" rows="5" style="resize: none" ng-model="properties.auditTaskRecommendation.description" maxlength="5000"></textarea>\n    </div>\n</div>'
    };
  });
