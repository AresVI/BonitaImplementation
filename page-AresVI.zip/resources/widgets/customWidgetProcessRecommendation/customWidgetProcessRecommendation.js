(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customWidgetProcessRecommendation', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope) {
    
},
      template: '<div class="panel panel-default">\n    <div class="panel-body">\n        <h4>Observaciones:</h4>\n         <select class="form-control" style="margin-bottom: 30px;" name="standard_observation" id="field_standard_observation"\n                    ng-model="properties.auditProcessRecommendation.standardObservation">\n            <option value=""> -- Sin observación predefinida -- </option>\n            <option ng-repeat="apso in properties.auditProcessStandardObservations" value="{{apso.observation}}">{{apso.observation}}</option>\n        </select>\n        <textarea class="form-control" rows="5" style="resize: none" ng-model="properties.auditProcessRecommendation.description" maxlength="5000"></textarea>\n    </div>\n</div>'
    };
  });
